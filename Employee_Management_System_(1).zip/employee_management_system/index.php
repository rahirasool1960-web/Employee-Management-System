<?php
declare(strict_types=1);

require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';

if (current_user()) {
    redirect('dashboard.php');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();

    $username = trim((string) ($_POST['username'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    $statement = $pdo->prepare(
        'SELECT user_id, username, password_hash, role, employee_id, full_name, status
         FROM users
         WHERE username = ?
         LIMIT 1'
    );
    $statement->execute([$username]);
    $user = $statement->fetch();

    $canSignIn = $user
        && $user['status'] === 'Active'
        && password_verify($password, $user['password_hash']);

    if ($canSignIn) {
        session_regenerate_id(true);

        unset($user['password_hash'], $user['status']);
        $_SESSION['user'] = $user;

        $updateLogin = $pdo->prepare(
            'UPDATE users SET last_login = NOW() WHERE user_id = ?'
        );
        $updateLogin->execute([$user['user_id']]);

        log_action($pdo, 'LOGIN', 'users', (int) $user['user_id']);
        redirect('dashboard.php');
    }

    $error = 'Invalid username or password.';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sign in | EMS</title>
    <link rel="icon" type="image/svg+xml" href="assets/ems-logo.svg">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body class="login-body">
    <main class="login-card">
        <div class="login-brand">
            <img src="assets/ems-logo.svg" alt="EMS logo" class="login-logo">
            <p class="login-kicker">EMPLOYEE MANAGEMENT SYSTEM</p>
            <h1>Welcome back</h1>
            <p class="login-subtitle">Sign in to continue to your workspace.</p>
        </div>

        <?php if ($error !== ''): ?>
            <div class="alert error" role="alert"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" class="login-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

            <label for="username">Username</label>
            <input
                id="username"
                type="text"
                name="username"
                placeholder="Enter your username"
                required
                autocomplete="username"
                autofocus
            >

            <label for="password">Password</label>
            <input
                id="password"
                type="password"
                name="password"
                placeholder="Enter your password"
                required
                autocomplete="current-password"
            >

            <button class="btn primary full login-submit" type="submit">Sign in</button>
        </form>

        <p class="login-footer">Secure access for authorised users</p>
    </main>
</body>
</html>
