<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/functions.php';
require_login();
$pageTitle = 'Dashboard';
$user = current_user();
$employeeCount = (int)$pdo->query("SELECT COUNT(*) FROM employees WHERE status='Active'")->fetchColumn();
$departmentCount = (int)$pdo->query("SELECT COUNT(*) FROM departments")->fetchColumn();
$todayStmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE work_date = CURDATE() AND status = 'Present'");
$todayStmt->execute();
$today = (int)$todayStmt->fetchColumn();
$pendingStmt = $pdo->prepare("SELECT COUNT(*) FROM leave_requests WHERE status = 'Pending'");
$pendingStmt->execute();
$pending = (int)$pendingStmt->fetchColumn();

$departmentStmt = $pdo->query("SELECT d.department_name, COUNT(e.employee_id) AS total FROM departments d LEFT JOIN employees e ON e.department_id = d.department_id AND e.status = 'Active' GROUP BY d.department_id, d.department_name ORDER BY total DESC, d.department_name ASC");
$departmentStats = $departmentStmt->fetchAll();
$maxDepartment = 1;
foreach ($departmentStats as $item) $maxDepartment = max($maxDepartment, (int)$item['total']);

$attendanceStmt = $pdo->query("SELECT status, COUNT(*) AS total FROM attendance WHERE work_date = CURDATE() GROUP BY status");
$attendanceRows = $attendanceStmt->fetchAll();
$attendanceCounts = ['Present' => 0, 'Absent' => 0, 'Leave' => 0];
foreach ($attendanceRows as $item) if (isset($attendanceCounts[$item['status']])) $attendanceCounts[$item['status']] = (int)$item['total'];
$maxAttendance = max(1, ...array_values($attendanceCounts));

$payrollStmt = $pdo->query("SELECT pay_period, SUM(net_pay) AS total FROM payroll GROUP BY pay_period ORDER BY pay_period DESC LIMIT 6");
$payrollStats = array_reverse($payrollStmt->fetchAll());
$maxPayroll = 1;
foreach ($payrollStats as $item) $maxPayroll = max($maxPayroll, (float)$item['total']);
require __DIR__ . '/includes/header.php';
?>
<section class="dashboard-intro"><div><p class="eyebrow">OVERVIEW</p><h1>Dashboard</h1><p class="muted">Welcome back, <?= e($user['full_name']) ?>. Here is your current workforce snapshot.</p></div><span class="dashboard-date"><?= e(date('d M Y')) ?></span></section>
<div class="stats">
  <div class="stat stat-teal"><span>Active employees</span><strong><?= $employeeCount ?></strong><small>Currently active</small></div>
  <div class="stat stat-blue"><span>Departments</span><strong><?= $departmentCount ?></strong><small>Across the organisation</small></div>
  <div class="stat stat-green"><span>Present today</span><strong><?= $today ?></strong><small>Attendance records</small></div>
  <div class="stat stat-amber"><span>Pending leave</span><strong><?= $pending ?></strong><small>Awaiting a decision</small></div>
</div>
<div class="charts-grid">
  <section class="panel chart-panel"><div class="chart-heading"><div><h2>Employees by department</h2><p class="chart-subtitle">Active employees in each department</p></div><span class="chart-icon">▥</span></div>
  <?php if (!$departmentStats): ?><p class="empty-chart">No department data is available yet.</p><?php else: ?><div class="bar-chart" role="img" aria-label="Bar chart showing active employees by department">
    <?php foreach ($departmentStats as $item): $value=(int)$item['total']; $width=($value/$maxDepartment)*100; ?><div class="bar-row"><div class="bar-label" title="<?= e($item['department_name']) ?>"><?= e($item['department_name']) ?></div><div class="bar-track"><div class="bar-fill teal-fill" style="width: <?= $width ?>%"></div></div><strong class="bar-value"><?= $value ?></strong></div><?php endforeach; ?>
  </div><?php endif; ?></section>
  <section class="panel chart-panel"><div class="chart-heading"><div><h2>Today's attendance</h2><p class="chart-subtitle">Records grouped by attendance status</p></div><span class="chart-icon">◷</span></div>
  <div class="attendance-chart" role="img" aria-label="Bar chart showing today's attendance statuses"><?php $attendanceColors=['Present'=>'green-fill','Absent'=>'red-fill','Leave'=>'amber-fill']; foreach ($attendanceCounts as $status=>$value): $width=($value/$maxAttendance)*100; ?><div class="attendance-item"><div class="attendance-label"><span class="legend-dot <?= e($attendanceColors[$status]) ?>"></span><?= e($status) ?></div><div class="bar-track"><div class="bar-fill <?= e($attendanceColors[$status]) ?>" style="width: <?= $width ?>%"></div></div><strong class="bar-value"><?= (int)$value ?></strong></div><?php endforeach; ?></div><p class="chart-footnote">Based on attendance entries recorded for today.</p></section>
  <section class="panel chart-panel chart-panel-wide"><div class="chart-heading"><div><h2>Monthly payroll</h2><p class="chart-subtitle">Total net pay by pay period</p></div><span class="chart-icon">₹</span></div>
  <?php if (!$payrollStats): ?><p class="empty-chart">No payroll records are available yet. Add payroll records to see this chart.</p><?php else: ?><div class="payroll-chart" role="img" aria-label="Bar chart showing payroll net totals by pay period"><?php foreach ($payrollStats as $item): $value=(float)$item['total']; $height=max(4,($value/$maxPayroll)*100); ?><div class="payroll-column"><span class="payroll-amount">₹<?= e(number_format($value,0)) ?></span><div class="payroll-bar-wrap"><div class="payroll-bar" style="height: <?= $height ?>%"></div></div><span class="payroll-period"><?= e($item['pay_period']) ?></span></div><?php endforeach; ?></div><?php endif; ?></section>
</div>
<section class="panel quick-actions-panel"><div class="chart-heading"><div><h2>Quick actions</h2><p class="chart-subtitle">Jump straight to a common task</p></div></div><div class="actions"><a class="btn primary" href="employees/index.php">Manage employees</a><a class="btn" href="attendance/index.php">Record attendance</a><a class="btn" href="leave/index.php">Leave requests</a><a class="btn" href="reports/index.php">View reports</a></div></section>
<section class="panel project-overview"><h2>Project overview</h2><p>This student prototype brings employee profiles, departments, attendance, leave requests, payroll summaries and reports into one place. Access to sensitive information depends on your role.</p></section>
<?php require __DIR__ . '/includes/footer.php'; ?>
