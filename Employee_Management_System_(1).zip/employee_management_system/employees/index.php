<?php
require_once __DIR__ . '/../config/database.php'; require_once __DIR__ . '/../includes/functions.php';
require_login();
$user = current_user(); $canManage = $user['role'] === 'Admin/HR';
$q = trim((string)($_GET['q'] ?? ''));
if ($user['role'] === 'Employee') {
    $stmt = $pdo->prepare("SELECT e.*, d.department_name, g.title AS designation FROM employees e LEFT JOIN departments d ON d.department_id=e.department_id LEFT JOIN designations g ON g.designation_id=e.designation_id WHERE e.employee_id=?");
    $stmt->execute([$user['employee_id']]);
} else {
    $sql = "SELECT e.*, d.department_name, g.title AS designation FROM employees e LEFT JOIN departments d ON d.department_id=e.department_id LEFT JOIN designations g ON g.designation_id=e.designation_id";
    $params = [];
    if ($q !== '') { $sql .= " WHERE e.name LIKE ? OR e.employee_code LIKE ? OR e.email LIKE ?"; $params = ["%$q%","%$q%","%$q%"]; }
    $sql .= " ORDER BY e.employee_id DESC";
    $stmt = $pdo->prepare($sql); $stmt->execute($params);
}
$rows = $stmt->fetchAll(); $pageTitle = 'Employees'; require __DIR__ . '/../includes/header.php';
?>
<div class="page-heading"><div><h1>Employees</h1><p class="muted">Employee directory and job details</p></div>
<?php if ($canManage): ?><a class="btn primary" href="form.php">+ Add employee</a><?php endif; ?></div>
<form class="searchbar" method="get"><input name="q" placeholder="Search name, employee code or email" value="<?= e($q) ?>"><button class="btn" type="submit">Search</button></form>
<div class="table-wrap"><table><thead><tr><th>Code</th><th>Name</th><th>Email</th><th>Department</th><th>Designation</th><th>Status</th><?php if($canManage): ?><th>Actions</th><?php endif; ?></tr></thead><tbody>
<?php foreach($rows as $r): ?><tr><td><?= e($r['employee_code']) ?></td><td><?= e($r['name']) ?></td><td><?= e($r['email']) ?></td><td><?= e($r['department_name'] ?? '—') ?></td><td><?= e($r['designation'] ?? '—') ?></td><td><span class="pill"><?= e($r['status']) ?></span></td>
<?php if($canManage): ?><td class="nowrap"><a href="form.php?id=<?= (int)$r['employee_id'] ?>">Edit</a> · <a class="danger-link" data-confirm="Deactivate this employee?" href="deactivate.php?id=<?= (int)$r['employee_id'] ?>">Deactivate</a></td><?php endif; ?></tr><?php endforeach; ?>
<?php if(!$rows): ?><tr><td colspan="<?= $canManage ? 7 : 6 ?>">No employee records found.</td></tr><?php endif; ?>
</tbody></table></div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
