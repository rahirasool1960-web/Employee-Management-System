<?php
require_once __DIR__ . '/../config/database.php'; require_once __DIR__ . '/../includes/functions.php'; require_roles(['Admin/HR']);
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT) ?: 0;
$employee = ['employee_code'=>'','name'=>'','email'=>'','phone'=>'','address'=>'','date_of_birth'=>'','hire_date'=>date('Y-m-d'),'department_id'=>'','designation_id'=>'','status'=>'Active'];
if ($id) { $st=$pdo->prepare('SELECT * FROM employees WHERE employee_id=?'); $st->execute([$id]); $employee=$st->fetch() ?: $employee; }
$departments=$pdo->query('SELECT department_id, department_name FROM departments ORDER BY department_name')->fetchAll();
$designations=$pdo->query('SELECT designation_id, title FROM designations ORDER BY title')->fetchAll();
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
 verify_csrf();
 foreach (['employee_code','name','email','phone','address','date_of_birth','hire_date','department_id','designation_id','status'] as $k) $employee[$k]=trim((string)($_POST[$k] ?? ''));
 if ($employee['employee_code']==='' || $employee['name']==='' || !filter_var($employee['email'], FILTER_VALIDATE_EMAIL)) $error='Employee code, name and a valid email are required.';
 else {
  try {
   $values=[$employee['employee_code'],$employee['name'],$employee['email'],$employee['phone'],$employee['address'] ?: null,$employee['date_of_birth'] ?: null,$employee['hire_date'] ?: null,$employee['department_id'] ?: null,$employee['designation_id'] ?: null,$employee['status']];
   if ($id) { $values[]=$id; $st=$pdo->prepare('UPDATE employees SET employee_code=?,name=?,email=?,phone=?,address=?,date_of_birth=?,hire_date=?,department_id=?,designation_id=?,status=? WHERE employee_id=?'); $st->execute($values); log_action($pdo,'UPDATE','employees',$id); }
   else { $st=$pdo->prepare('INSERT INTO employees (employee_code,name,email,phone,address,date_of_birth,hire_date,department_id,designation_id,status) VALUES (?,?,?,?,?,?,?,?,?,?)'); $st->execute($values); log_action($pdo,'CREATE','employees',(int)$pdo->lastInsertId()); }
   flash('Employee record saved.'); redirect('index.php');
  } catch (PDOException $ex) { $error='Could not save. Employee code or email may already exist.'; }
 }
}
$pageTitle=$id?'Edit employee':'Add employee'; require __DIR__ . '/../includes/header.php';
?>
<h1><?= $id?'Edit employee':'Add employee' ?></h1>
<?php if($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
<form method="post" class="panel form-grid"><input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
<label>Employee code *<input name="employee_code" required value="<?= e($employee['employee_code']) ?>"></label>
<label>Full name *<input name="name" required value="<?= e($employee['name']) ?>"></label>
<label>Email *<input type="email" name="email" required value="<?= e($employee['email']) ?>"></label>
<label>Phone<input name="phone" value="<?= e($employee['phone']) ?>"></label>
<label>Date of birth<input type="date" name="date_of_birth" value="<?= e($employee['date_of_birth']) ?>"></label>
<label>Joining date<input type="date" name="hire_date" value="<?= e($employee['hire_date']) ?>"></label>
<label>Department<select name="department_id"><option value="">Select department</option><?php foreach($departments as $d): ?><option value="<?= $d['department_id'] ?>" <?= (string)$employee['department_id']===(string)$d['department_id']?'selected':'' ?>><?= e($d['department_name']) ?></option><?php endforeach; ?></select></label>
<label>Designation<select name="designation_id"><option value="">Select designation</option><?php foreach($designations as $d): ?><option value="<?= $d['designation_id'] ?>" <?= (string)$employee['designation_id']===(string)$d['designation_id']?'selected':'' ?>><?= e($d['title']) ?></option><?php endforeach; ?></select></label>
<label>Status<select name="status"><option <?= $employee['status']==='Active'?'selected':'' ?>>Active</option><option <?= $employee['status']==='Inactive'?'selected':'' ?>>Inactive</option></select></label>
<label class="span-2">Address<textarea name="address" rows="2"><?= e($employee['address']) ?></textarea></label>
<div class="form-actions span-2"><button class="btn primary">Save employee</button><a class="btn" href="index.php">Cancel</a></div></form>
<?php require __DIR__ . '/../includes/footer.php'; ?>
