<?php
require_once __DIR__ . '/../config/database.php'; require_once __DIR__ . '/../includes/functions.php'; require_roles(['Admin/HR']);
$id=filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT);
if($id){$st=$pdo->prepare("UPDATE employees SET status='Inactive' WHERE employee_id=?");$st->execute([$id]);log_action($pdo,'DEACTIVATE','employees',$id);flash('Employee deactivated.');}
redirect('index.php');
