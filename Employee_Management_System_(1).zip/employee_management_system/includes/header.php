<?php
require_once __DIR__ . '/functions.php';

require_login();

$user = current_user();
$base = '/employee_management_system';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'Employee Management System') ?></title>
    <link rel="icon" type="image/svg+xml" href="<?= $base ?>/assets/ems-logo.svg">
    <link rel="stylesheet" href="<?= $base ?>/assets/style.css">
    <script defer src="<?= $base ?>/assets/app.js"></script>
</head>
<body>
    <header class="topbar">
        <a class="brand" href="<?= $base ?>/dashboard.php" aria-label="EMS dashboard">
            <img src="<?= $base ?>/assets/ems-logo.svg" alt="" class="brand-logo">
            <span class="brand-copy">
                <strong>EMS</strong>
                <small>Employee Management System</small>
            </span>
        </a>

        <div class="userbox">
            <span><?= e($user['full_name']) ?></span>
            <span class="role"><?= e($user['role']) ?></span>
            <span aria-hidden="true">·</span>
            <a href="<?= $base ?>/logout.php">Logout</a>
        </div>
    </header>

    <div class="layout">
        <aside class="sidebar" aria-label="Main navigation">
            <a href="<?= $base ?>/dashboard.php">Dashboard</a>
            <a href="<?= $base ?>/employees/index.php">Employees</a>

            <?php if (in_array($user['role'], ['Admin/HR', 'Manager'], true)): ?>
                <a href="<?= $base ?>/departments/index.php">Departments</a>
            <?php endif; ?>

            <a href="<?= $base ?>/attendance/index.php">Attendance</a>
            <a href="<?= $base ?>/leave/index.php">Leave requests</a>

            <?php if ($user['role'] === 'Admin/HR'): ?>
                <a href="<?= $base ?>/payroll/index.php">Payroll</a>
            <?php endif; ?>

            <a href="<?= $base ?>/reports/index.php">Reports</a>
        </aside>

        <main class="content">
            <?php
            if (!empty($_SESSION['flash'])):
                $flash = $_SESSION['flash'];
                unset($_SESSION['flash']);
            ?>
                <div class="alert <?= e($flash['type']) ?>">
                    <?= e($flash['message']) ?>
                </div>
            <?php endif; ?>
