        </main>
    </div>

    <footer class="footer">
        Employee Management System <span aria-hidden="true">·</span>
        Student project prototype <span aria-hidden="true">·</span>
        Use fictional data only
    </footer>
</body>
</html>
