CREATE DATABASE IF NOT EXISTS employee_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE employee_management;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS payroll;
DROP TABLE IF EXISTS leave_requests;
DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS employees;
DROP TABLE IF EXISTS designations;
DROP TABLE IF EXISTS departments;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE departments (
 department_id INT AUTO_INCREMENT PRIMARY KEY,
 department_name VARCHAR(100) NOT NULL UNIQUE,
 manager_id INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE designations (
 designation_id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(100) NOT NULL UNIQUE,
 grade_level VARCHAR(50) NULL
) ENGINE=InnoDB;

CREATE TABLE employees (
 employee_id INT AUTO_INCREMENT PRIMARY KEY,
 employee_code VARCHAR(30) NOT NULL UNIQUE,
 name VARCHAR(120) NOT NULL,
 email VARCHAR(160) NOT NULL UNIQUE,
 phone VARCHAR(30) NULL,
 address TEXT NULL,
 date_of_birth DATE NULL,
 hire_date DATE NULL,
 department_id INT NULL,
 designation_id INT NULL,
 status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_employee_department FOREIGN KEY (department_id) REFERENCES departments(department_id) ON DELETE SET NULL,
 CONSTRAINT fk_employee_designation FOREIGN KEY (designation_id) REFERENCES designations(designation_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE users (
 user_id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(80) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role ENUM('Admin/HR','Manager','Employee') NOT NULL,
 employee_id INT NULL,
 full_name VARCHAR(120) NOT NULL,
 status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
 last_login DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_user_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE attendance (
 attendance_id INT AUTO_INCREMENT PRIMARY KEY,
 employee_id INT NOT NULL,
 work_date DATE NOT NULL,
 check_in TIME NULL,
 check_out TIME NULL,
 status ENUM('Present','Absent','Leave') NOT NULL DEFAULT 'Present',
 recorded_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_employee_work_date (employee_id, work_date),
 CONSTRAINT fk_attendance_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE,
 CONSTRAINT fk_attendance_user FOREIGN KEY (recorded_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE leave_requests (
 leave_id INT AUTO_INCREMENT PRIMARY KEY,
 employee_id INT NOT NULL,
 leave_type VARCHAR(50) NOT NULL DEFAULT 'Annual',
 start_date DATE NOT NULL,
 end_date DATE NOT NULL,
 reason TEXT NOT NULL,
 status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
 approved_by INT NULL,
 decision_at DATETIME NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_leave_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE,
 CONSTRAINT fk_leave_approver FOREIGN KEY (approved_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE payroll (
 payroll_id INT AUTO_INCREMENT PRIMARY KEY,
 employee_id INT NOT NULL,
 pay_period CHAR(7) NOT NULL,
 basic_pay DECIMAL(12,2) NOT NULL DEFAULT 0,
 allowances DECIMAL(12,2) NOT NULL DEFAULT 0,
 deductions DECIMAL(12,2) NOT NULL DEFAULT 0,
 net_pay DECIMAL(12,2) NOT NULL DEFAULT 0,
 created_by INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 UNIQUE KEY uq_employee_period (employee_id, pay_period),
 CONSTRAINT fk_payroll_employee FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE,
 CONSTRAINT fk_payroll_user FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE audit_log (
 log_id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NULL,
 action VARCHAR(60) NOT NULL,
 entity VARCHAR(80) NOT NULL,
 record_id INT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO departments(department_name) VALUES
('Information Technology'),('Human Resources'),('Finance'),('Operations');

INSERT INTO designations(title,grade_level) VALUES
('System Administrator','L2'),('HR Executive','L2'),('Accountant','L2'),('Operations Manager','L3'),('Software Developer','L1');

INSERT INTO employees(employee_code,name,email,phone,address,hire_date,department_id,designation_id,status) VALUES
('EMP001','Aarav Sharma','aarav@example.test','9000000001','Demo address, Srinagar','2025-01-15',1,5,'Active'),
('EMP002','Sara Khan','sara@example.test','9000000002','Demo address, Srinagar','2024-09-01',2,2,'Active'),
('EMP003','Rohan Gupta','rohan@example.test','9000000003','Demo address, Srinagar','2024-05-20',3,3,'Active');

-- Demo password for each account is "password"; PHP password_hash hashes are inserted below.
INSERT INTO users(username,password_hash,role,employee_id,full_name,status) VALUES
('admin','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.','Admin/HR',NULL,'Demo Administrator','Active'),
('manager','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.','Manager',NULL,'Demo Manager','Active'),
('employee','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.','Employee',1,'Aarav Sharma','Active');

INSERT INTO attendance(employee_id,work_date,check_in,check_out,status) VALUES
(1,CURDATE(),'09:00:00','17:00:00','Present'),
(2,CURDATE(),'09:15:00','17:05:00','Present'),
(3,CURDATE(),'09:05:00','16:55:00','Present');

INSERT INTO leave_requests(employee_id,leave_type,start_date,end_date,reason,status) VALUES
(2,'Annual',DATE_ADD(CURDATE(), INTERVAL 7 DAY),DATE_ADD(CURDATE(), INTERVAL 8 DAY),'Demo sample leave request','Pending');

INSERT INTO payroll(employee_id,pay_period,basic_pay,allowances,deductions,net_pay) VALUES
(1,DATE_FORMAT(CURDATE(),'%Y-%m'),25000,3000,1000,27000);
