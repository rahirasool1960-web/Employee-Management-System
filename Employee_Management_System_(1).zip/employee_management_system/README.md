# Employee Management System (EMS)

A student-project prototype based on the supplied project proposal.

## Technology
- HTML5, CSS3, JavaScript
- PHP 8+
- MySQL / MariaDB
- XAMPP (Apache + MySQL)
- phpMyAdmin

## Modules included
- Login/logout with role-based access (Admin/HR, Manager, Employee)
- Dashboard summary
- Employee CRUD (add, view, search, edit, deactivate)
- Departments and designations
- Attendance recording and summaries
- Leave requests and manager/admin approval
- Payroll records (restricted to Admin/HR; employees can see their own records)
- Printable reports
- Audit log for selected actions

This is an educational prototype. Use fictional data only. Before any real deployment, arrange a security review and adapt it to local privacy, employment, and payroll requirements.

## Installation in XAMPP (Windows)
1. Copy the `employee_management_system` folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** in XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Import `database/employee_management.sql`.
5. Open `config/database.php` and set your database username/password if different from the XAMPP defaults (`root` with an empty password is common for local installations).
6. Visit `http://localhost/employee_management_system/`.
7. Sign in using one of the demo accounts below.

## Demo accounts
The SQL import creates demo accounts with these usernames and passwords:
- Admin: `admin` / `password`
- Manager: `manager` / `password`
- Employee: `employee` / `password`

**Important:** These are demonstration credentials only. Change them before showing the project outside your local machine. Passwords are stored as hashes in the database.

## Suggested demonstration
1. Sign in as Admin and add a department and employee.
2. Search and edit an employee record.
3. Add attendance for the employee.
4. Submit a leave request as the employee, then approve it as Manager/Admin.
5. Add a payroll record as Admin and view the appropriate summary.
6. Open Reports and print a report.

## Project structure
- `index.php` — login
- `dashboard.php` — dashboard
- `employees/` — employee records
- `departments/` — departments and designations
- `attendance/` — attendance records
- `leave/` — leave request and approval
- `payroll/` — salary records
- `reports/` — printable reports
- `includes/` — shared header, footer, auth and helpers
- `config/` — database connection
- `database/employee_management.sql` — schema and fictional sample data

## Scope notes
- The payroll module stores and summarizes the amounts entered; it does not calculate tax or perform bank transfers.
- Attendance is manually entered; biometric integrations are out of scope.
- Password reset is not automated in this prototype.
- For a real deployment, use HTTPS, strong unique passwords, secure hosting, CSRF protection on all state-changing forms, rate limiting, proper backup procedures, and a reviewed access-control policy.

## Dashboard charts
The dashboard includes database-driven bar charts for active employees by department, today's attendance statuses, and monthly payroll totals. Charts are rendered with PHP and CSS, so no external chart library or internet connection is required. The charts update from MySQL when the dashboard is refreshed.


## Branding and source code
- `assets/ems-logo.svg` is the project logo used on the sign-in page, browser tab, and main navigation.
- The login and shared navigation files are formatted with descriptive variable names and comments where useful to make them easier to read and explain.


The sign-in page has a centered logo, a simplified login form, and a responsive navy/teal background. Demo account details are intentionally not displayed on the public sign-in page.
