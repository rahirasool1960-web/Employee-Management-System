# Employee Management System
## Minor Project Report

**Project type:** Web application  
**Technologies:** HTML5, CSS3, JavaScript, PHP, MySQL  
**Local environment:** XAMPP  
**Project objective:** To provide a centralised platform for managing employee profiles and selected HR activities.

## 1. Introduction
The Employee Management System (EMS) is a web-based application intended to keep employee records in one searchable location. It demonstrates web development, database connectivity, authentication, CRUD operations, role-based access and reporting.

## 2. Problem Statement
Paper records and separate spreadsheets can lead to duplicate information, slow searching, calculation mistakes and weak control of confidential employee information. EMS offers a single database for employee records, attendance, leave requests and payroll summaries.

## 3. Objectives
- Store and search employee information centrally.
- Maintain departments and designations.
- Record attendance and view attendance history.
- Submit and review leave requests.
- Store salary summaries with restricted access.
- Provide printable employee and attendance reports.
- Demonstrate basic validation, authentication and role permissions.

## 4. Scope
The prototype includes login/logout, dashboard, employee records, departments/designations, attendance, leave management, payroll storage and reports. Biometric attendance, automated bank transfers, tax-compliance calculations, external HR integrations and native mobile apps are not included.

## 5. Technology Used
- **HTML:** page structure and forms.
- **CSS:** responsive interface styling.
- **JavaScript:** small client-side interactions.
- **PHP:** server-side processing, authentication and database operations.
- **MySQL:** structured data storage.
- **XAMPP:** local Apache/PHP/MySQL development environment.
- **Visual Studio Code:** code editor.
- **phpMyAdmin:** database import and management.

## 6. System Architecture
The system uses a three-tier architecture:
1. **Presentation layer:** HTML, CSS and JavaScript in the browser.
2. **Application layer:** PHP validates requests, applies business rules and checks user roles.
3. **Data layer:** MySQL stores users, employees, departments, designations, attendance, leave requests, payroll and audit events.

## 7. User Roles
- **Admin/HR:** manages employee records, departments, attendance, leave oversight, payroll and reports.
- **Manager:** views permitted employee/team information, records attendance and approves or rejects leave requests.
- **Employee:** views own profile, attendance and payroll summary, and can submit leave requests.

## 8. Database Design
The database includes:
- `users`: usernames, password hashes, role and account status.
- `employees`: employee code, name, contact, hire date and related department/designation.
- `departments`: department names.
- `designations`: job titles.
- `attendance`: daily attendance status and check-in/out times.
- `leave_requests`: leave type, dates, reason and decision.
- `payroll`: pay period, basic pay, allowances, deductions and net pay.
- `audit_log`: selected user actions.

Foreign keys connect employee records to departments, designations, attendance, leave and payroll. Unique constraints prevent duplicate employee codes/emails and duplicate daily attendance for one employee.

## 9. Main Modules
### 9.1 Login and user management
Users sign in with a username and password. PHP verifies a stored password hash and creates a session. Navigation and restricted pages depend on the user's role.

### 9.2 Employee management
Admin/HR can add, view, search, update and deactivate employees. Employee fields include code, name, email, phone, address, date of birth, hire date, department, designation and status.

### 9.3 Department and designation management
Admin/HR can add department names and designations. The page displays employee counts by department.

### 9.4 Attendance management
Authorised users can record a work date, check-in time, check-out time and status. The employee role sees its own attendance records.

### 9.5 Leave management
Employees submit leave requests. Admin/HR and managers can approve or reject pending requests.

### 9.6 Payroll
Admin/HR can enter salary components. Net pay is calculated as basic pay + allowances − deductions. Payroll access is restricted; this module does not implement tax compliance or bank payments.

### 9.7 Reports
The reports page displays employee directory and recent attendance data and supports browser printing.

## 10. Security and Validation
The prototype uses PDO prepared statements, HTML output escaping, password verification, session ID regeneration on login, role checks and CSRF tokens for most form submissions. Demo credentials are provided for classroom testing only. The project is not production-ready and requires further security review before real deployment.

## 11. Testing Plan
| Test | Expected result |
|---|---|
| Correct demo login | Dashboard opens |
| Incorrect password | Error message appears |
| Add employee with valid fields | Record is saved and displayed |
| Duplicate employee code/email | Save is rejected with a helpful message |
| Search employee | Matching records are displayed |
| Employee tries to open payroll administration | Access is denied |
| Submit valid leave request | Request appears as Pending |
| Manager/Admin approves leave | Status changes to Approved |
| Save attendance for same employee/date again | Existing record is updated |
| Print report | Browser print dialog opens |

## 12. Installation
1. Copy the folder into XAMPP's `htdocs` directory.
2. Start Apache and MySQL.
3. Import `database/employee_management.sql` through phpMyAdmin.
4. Confirm database credentials in `config/database.php`.
5. Open `http://localhost/employee_management_system/`.
6. Sign in with one of the demo accounts described in `README.md`.

## 13. Limitations and Future Enhancements
Possible future work includes secure password reset, more comprehensive CSRF coverage, stronger audit trails, CSV/PDF exports, configurable leave balances, advanced filtering, automated backups, deployment with HTTPS and an independent security assessment.

## 14. Conclusion
The Employee Management System demonstrates how a web application can centralise employee data and selected HR workflows. It combines a browser-based interface, PHP server logic and a MySQL database. The prototype supports employee record management, attendance, leave requests, payroll summaries and printable reports, while advanced integrations and organisation-specific compliance remain future work.

## References
1. PHP Manual: https://www.php.net/manual/en/
2. MySQL Reference Manual: https://dev.mysql.com/doc/
3. Apache Friends XAMPP: https://www.apachefriends.org/
4. MDN HTML: https://developer.mozilla.org/en-US/docs/Web/HTML
5. MDN CSS: https://developer.mozilla.org/en-US/docs/Web/CSS
6. MDN JavaScript: https://developer.mozilla.org/en-US/docs/Web/JavaScript
