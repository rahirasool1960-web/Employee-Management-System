<?php
require_once __DIR__ . '/../config/database.php'; require_once __DIR__ . '/../includes/functions.php'; require_login();
$user=current_user();
$employeeSql="SELECT e.employee_code,e.name,e.email,e.phone,d.department_name,g.title AS designation,e.status FROM employees e LEFT JOIN departments d ON d.department_id=e.department_id LEFT JOIN designations g ON g.designation_id=e.designation_id";
$params=[];if($user['role']==='Employee'){$employeeSql.=" WHERE e.employee_id=?";$params[]=$user['employee_id'];}
$st=$pdo->prepare($employeeSql);$st->execute($params);$employees=$st->fetchAll();
$attSql="SELECT a.work_date,e.employee_code,e.name,a.check_in,a.check_out,a.status FROM attendance a JOIN employees e ON e.employee_id=a.employee_id";$ap=[];if($user['role']==='Employee'){$attSql.=" WHERE a.employee_id=?";$ap[]=$user['employee_id'];}$attSql.=" ORDER BY a.work_date DESC LIMIT 100";$st=$pdo->prepare($attSql);$st->execute($ap);$attendance=$st->fetchAll();
$pageTitle='Reports';require __DIR__ . '/../includes/header.php';
?>
<div class="page-heading"><div><h1>Reports</h1><p class="muted">Printable employee directory and attendance summary</p></div><button class="btn primary" onclick="window.print()">Print reports</button></div>
<section class="panel"><h2>Employee directory</h2><div class="table-wrap"><table><thead><tr><th>Code</th><th>Name</th><th>Email</th><th>Phone</th><th>Department</th><th>Designation</th><th>Status</th></tr></thead><tbody><?php foreach($employees as $r): ?><tr><?php foreach($r as $v): ?><td><?= e((string)($v??'—')) ?></td><?php endforeach; ?></tr><?php endforeach; ?></tbody></table></div></section>
<section class="panel"><h2>Attendance report (latest 100)</h2><div class="table-wrap"><table><thead><tr><th>Date</th><th>Code</th><th>Name</th><th>Check in</th><th>Check out</th><th>Status</th></tr></thead><tbody><?php foreach($attendance as $r): ?><tr><td><?= e($r['work_date']) ?></td><td><?= e($r['employee_code']) ?></td><td><?= e($r['name']) ?></td><td><?= e($r['check_in']??'—') ?></td><td><?= e($r['check_out']??'—') ?></td><td><?= e($r['status']) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
