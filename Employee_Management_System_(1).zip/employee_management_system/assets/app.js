document.addEventListener('click', function (event) {
  const link = event.target.closest('[data-confirm]');
  if (link && !window.confirm(link.getAttribute('data-confirm') || 'Are you sure?')) {
    event.preventDefault();
  }
});
